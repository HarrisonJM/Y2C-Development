#include "Car.h"

Car::Car()
{
	//pretend I didn't grab an average
}

Car::~Car()
{
}

double Car::getCarbonFootPrint()
{
	double averageCarbon = 19.33; //peryear
	double footprint;

	footprint = averageCarbon;

	return footprint;
}
