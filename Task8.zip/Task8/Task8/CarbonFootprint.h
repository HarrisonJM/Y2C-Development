#pragma once
 

class CarbonFootprint
{
private:

public:
	virtual double getCarbonFootPrint() = 0;
};